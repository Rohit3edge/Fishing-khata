import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import SettingsService from "../../services/settings.service";

export const Getsettings = createAsyncThunk(
    "/get/getsettings",
    async (thunkAPI) => {
        try {
            const data = await SettingsService.Getsettings();
            return data;
        } catch (error) {
            const message =
                (error.response &&
                    error.response.data &&
                    error.response.data.message) ||
                error.message ||
                error.toString();
            return thunkAPI.rejectWithValue({ message });
        }
    }
);

const initialState = {
    loading: false,
    error: "",
    user: null,
};

const SettingsSlice = createSlice({
    name: "Getsettings",
    initialState,
    extraReducers: (builder) => {
        builder
            .addCase(Getsettings.pending, (state) => {
                state.loading = true;
                state.error = "";
                state.user = null;
            })
            .addCase(Getsettings.fulfilled, (state, action) => {
                state.loading = false;
                state.user = action.payload;
            })
            .addCase(Getsettings.rejected, (state, action) => {
                state.loading = false;
                state.error = action.payload.message;
            });
    },
});

const { reducer } = SettingsSlice;
export default reducer;
