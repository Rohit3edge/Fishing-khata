import React from 'react'

const SettingsItem = () => {
  return (
    <div className='row'>
        
         <div className="col-sm-6">
            <div className="col-sm-12 mt_20 d-flex justify-content-between align-items-center mt-2 mb-2">
                <div className="dis_in title_2 ">
                    What do you sell?
                    <div className="" title="Select the type of item you sell (product / service or both)">
                        <i className="glyphicon glyphicon-info-sign"></i>
                    </div>
                </div>
                <div className="">
                    <select
                        name="sell_type"
                        id="sell_type"
                        // value={sellType}
                        // onChange={handleSellTypeChange}
                        className="dis_in form-control pad_2"
                        style={{ fontSize: '12px', height: '25px', width: '110px' }}
                    >
                        <option value="Product/Service">Product/Service</option>
                        <option value="Product">Product</option>
                        <option value="Service">Service</option>
                    </select>
                </div>
            </div>

            <div className="col-sm-12 mt_20 d-flex justify-content-between align-items-center mt-2 mb-2">
                <div className="dis_in title_2">
                    Set default item unit
                    <div className="dis_in" title="Define a default unit for your most use product.">
                        <i className="glyphicon glyphicon-info-sign"></i>
                    </div>
                </div>
                <div className="">
                <select
                        name="sell_type"
                        id="sell_type"
                        // value={sellType}
                        // onChange={handleSellTypeChange}
                        className="dis_in form-control pad_2"
                        style={{ fontSize: '12px', height: '25px', width: '110px' }}
                    >
                        <option value="Product/Service">Product/Service</option>
                        <option value="Product">Product</option>
                        <option value="Service">Service</option>
                    </select>
                 
                </div>
            </div>

            <div className="col-sm-12 mt_20 d-flex justify-content-between align-items-center mt-2 mb-2">
                <div className="dis_in title_2">
                    Set default GST rate
                    <div className="dis_in" title="Define a default GST tax rate that is applicable for your product or service like GST 5%, IGST 18% etc.">
                        <i className="glyphicon glyphicon-info-sign"></i>
                    </div>
                </div>
                <div className="dis_in flot_right">
                    <select
                        name="gst_rate"
                        id="gst_rate"
                        // value={gstRate}
                        // onChange={handleGstRateChange}
                        className="dis_in form-control pad_2"
                        style={{ fontSize: '12px', height: '25px', width: '110px' }}
                    >
                        <option value="NONE">NONE</option>
                        <option value="GST@0%">GST@0%</option>
                        <option value="GST@0.25%">GST@0.25%</option>
                        <option value="GST@3%">GST@3%</option>
                        <option value="GST@5%">GST@5%</option>
                        <option value="GST@12%">GST@12%</option>
                        <option value="GST@18%">GST@18%</option>
                        <option value="GST@28%">GST@28%</option>
                        <option value="Exempted">Exempted</option>
                    </select>
                </div>
            </div>

            <div className="col-sm-12 mt_20 d-flex justify-content-between align-items-center mt-2 mb-2">
                <div className="dis_in title_2">
                    Set default item category
                    <div className="dis_in" title="Define a default category for most using items.">
                        <i className="glyphicon glyphicon-info-sign"></i>
                    </div>
                </div>
                <div className="dis_in flot_right">
                    <select
                        name="category_list"
                        id="category_list"
                        // value={category}
                        // onChange={handleCategoryChange}
                        className="dis_in form-control pad_2"
                        style={{ fontSize: '12px', height: '25px', width: '110px' }}
                    >
                        <option value="General">General</option>
                    </select>
                </div>
            </div>

            <div className="col-sm-12 mt_20 d-flex justify-content-between align-items-center mt-2 mb-2">
                <div className="dis_in title_2">
                    Set low stock value
                    <div className="dis_in" title="Add low stock value to get alert.">
                        <i className="glyphicon glyphicon-info-sign"></i>
                    </div>
                </div>
                <div className="dis_in flot_right" style={{ width: '120px' }}>
                    <div className="input-group mb-0">
                        <input
                            name="low_stock_txt"
                            type="number"
                            // value={lowStockValue}
                            // onChange={handleLowStockValueChange}
                            className="form-control"
                        />
                        <span className="input-group-btn">
                            <button
                                type="button"
                                // onClick={handleSetLowStock}
                                className="btn btn-primary"
                            >
                                Set
                            </button>
                        </span>
                    </div>
                </div>
            </div>

            <div className="col-sm-12 mt_20 d-flex justify-content-between align-items-center mt-2 mb-2">
                <div className="dis_in title_2">
                    Show low stock notification
                    <div className="dis_in" title="Allow low stock notification to get low stock alert.">
                        <i className="glyphicon glyphicon-info-sign"></i>
                    </div>
                </div>
                <div className="flot_right form-check form-switch">
                    
                        <input
                            type="checkbox"
                            id="chk_low_stock"
                            // checked={lowStockNotification}
                            // onChange={() => setLowStockNotification(!lowStockNotification)}
                        />
                 
                </div>
            </div>
        </div>
    </div>
  )
}

export default SettingsItem