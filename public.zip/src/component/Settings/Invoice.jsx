import React from "react";

const Invoice = ({data}) => {
  console.log(data.invoice_account_type)
  return (
    <div>
      <div className="row">
        <div className="col-md-12 col-sm-12 pt-1">
          <div className="col-sm-6">
            {/* Invoice Account Type */}
            <div className="col-sm-12 mt_20 d-flex justify-content-between align-items-center mt-2 mb-2">
              <div className="dis_in title_2">
                Set Invoice Account Type
                <div
                  className="dis_in"
                  title="Set default type of invoice in terms of Accounting like Cash, Credit."
                >
                  <i className="glyphicon glyphicon-info-sign"></i>
                </div>
              </div>
              <div className="dis_in flot_right">
                <select
                  name="invoice_account_type"
                  className="dis_in form-control pad_2"
                  style={{ fontSize: "12px", height: "30px", width: "85px" }}
                  value={data.invoice_account_type}
                >
                  <option selected="selected" value="Cash">
                    Cash
                  </option>
                  <option value="Credit">Credit</option>
                </select>
              </div>
            </div>

            {/* Default Payment Mode */}
            <div className="col-sm-12 mt_20 d-flex justify-content-between align-items-center mt-2 mb-2">
              <div className="dis_in title_2">
                Set default Payment Mode
                <div
                  className="dis_in"
                  title="Set default payment mode of invoice like Cash, Debit/Credit Card etc."
                >
                  <i className="glyphicon glyphicon-info-sign"></i>
                </div>
              </div>
              <div className="dis_in flot_right">
                <select
                  name="payment_mode"
                  className="dis_in form-control pad_2"
                  style={{ fontSize: "12px", height: "30px", width: "85px" }}
                >
                  <option selected="selected" value="Cash">
                    Cash
                  </option>
                  <option value="Debit/Credit Card">Debit/Credit Card</option>
                  <option value="Cheque">Cheque</option>
                  <option value="Mobile Wallet">Mobile Wallet</option>
                  <option value="Bank Transfer">Bank Transfer</option>
                  <option value="Demand Draft">Demand Draft</option>
                </select>
              </div>
            </div>

            {/* Enable E-Way Bill Number */}
            <div className="col-sm-12 mt_20 d-flex justify-content-between align-items-center mt-2 mb-2">
              <div className="dis_in title_2">
                Enable E-Way Bill Number
                <div
                  className="dis_in"
                  title="Enable you to add E-Way bill no in your invoice."
                >
                  <i className="glyphicon glyphicon-info-sign"></i>
                </div>
              </div>
              <div className="flot_right form-check form-switch">
                <input type="checkbox" name="chk_ewaybill" />
              </div>
            </div>

            {/* Invoice Shipping Address */}
            <div className="col-sm-12 mt_20 d-flex justify-content-between align-items-center mt-2 mb-2">
              <div className="dis_in title_2">
                Invoice Shipping Address
                <div
                  className="dis_in"
                  title="Enable you to add Invoice Shipping Address in your invoice."
                >
                  <i className="glyphicon glyphicon-info-sign"></i>
                </div>
              </div>
              <div className="flot_right form-check form-switch">
                <input type="checkbox" name="chk_invo_shiping_address" />
              </div>
            </div>

            {/* Default Terms and Conditions */}
            <div className="col-sm-12 mt_20  mt-2 mb-2">
              <div className="dis_in title_2">
                Set Default Terms and Conditions
                <div
                  className="dis_in"
                  title="Set default Terms and Conditions."
                >
                  <i className="glyphicon glyphicon-info-sign"></i>
                </div>
              </div>
              <div className="dis_in flot_right">
                <div className="input-group">
                  <textarea
                    name="MainContent2$ctl02$invoice_terms"
                    value="Thanks for doing business with us!"
                    className="form-control mt-2 mb-2"
                    rows="3" // This sets the height of the textarea; adjust as needed
                  ></textarea>
                  <div className="input-group-btn d-flex justify-content-end w-100">
                    <input
                      type="submit"
                      name="MainContent$MainContent2$ctl02$Button1"
                      value="Save"
                      className="btn btn-primary"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Upload Signature */}
            <div className="col-sm-12 mt_20 d-flex justify-content-between align-items-center mt-2 mb-2">
              <div className="dis_in title_2">
                Upload Signature
                <div
                  className="dis_in"
                  title="Set default signature to invoice."
                ></div>
              </div>
              <div className="dis_in flot_right" style={{ width: "196px" }}>
                <div className="input-group d-flex justify-content-between align-items-center">
                  <input
                    type="file"
                    name="img_profile"
                    className="form-control"
                    accept=".png,.jpg,.jpeg"
                    style={{ width: "110px" }}
                  />
                  {/* <img
                    id="MainContent_MainContent2_ctl02_Avatar_profile"
                    className="dis_none"
                    style={{ height: "100px", width: "100px" }}
                  /> */}
                  {/* <span
                    id="MainContent_MainContent2_ctl02_lbl_image_name_profile"
                    style={{ color: "White", fontSize: "2px" }}
                  ></span> */}
                  <span className="input-group-btn">
                    <input
                      type="submit"
                      name="MainContent2$ctl02$Button5"
                      value="Upload"
                      className="btn btn-primary"
                    />
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Invoice;
